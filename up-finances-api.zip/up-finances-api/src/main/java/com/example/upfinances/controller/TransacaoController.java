package com.example.upfinances.controller;

import com.example.upfinances.model.Transacao;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/transacoes")
public class TransacaoController {

    private final List<Transacao> transacoes = new ArrayList<>();

    private final AtomicLong contadorId = new AtomicLong(1);

    @GetMapping
    public ResponseEntity<List<Transacao>> listar(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) String categoria,
            @RequestParam(required = false) String descricao,
            @RequestParam(required = false) BigDecimal valorMin,
            @RequestParam(required = false) BigDecimal valorMax) {

        List<Transacao> resultado = transacoes.stream()
                .filter(t -> tipo == null || t.getTipo().equalsIgnoreCase(tipo))
                .filter(t -> categoria == null || t.getCategoria().equalsIgnoreCase(categoria))
                .filter(t -> descricao == null || t.getDescricao().toLowerCase().contains(descricao.toLowerCase()))
                .filter(t -> valorMin == null || t.getValor().compareTo(valorMin) >= 0)
                .filter(t -> valorMax == null || t.getValor().compareTo(valorMax) <= 0)
                .collect(Collectors.toList());

        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Transacao> buscarPorId(@PathVariable Long id) {
        return transacoes.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Transacao> cadastrar(@RequestBody Transacao novaTransacao) {
        novaTransacao.setId(contadorId.getAndIncrement());
        transacoes.add(novaTransacao);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaTransacao);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Transacao> atualizar(@PathVariable Long id, @RequestBody Transacao dadosAtualizados) {
        for (Transacao t : transacoes) {
            if (t.getId().equals(id)) {
                t.setDescricao(dadosAtualizados.getDescricao());
                t.setValor(dadosAtualizados.getValor());
                t.setTipo(dadosAtualizados.getTipo());
                t.setCategoria(dadosAtualizados.getCategoria());
                t.setData(dadosAtualizados.getData());
                return ResponseEntity.ok(t);
            }
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        boolean removido = transacoes.removeIf(t -> t.getId().equals(id));
        return removido
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
