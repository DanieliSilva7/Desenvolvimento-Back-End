# Up Finances API

API REST simples de organização financeira pessoal (projeto **Up Finances**), feita em Java + Spring Boot, com dados **em memória** (sem banco de dados) — apenas camadas `model` e `controller`.

## Modelo

```
Transacao {
  id: Long (gerado manualmente no controller)
  descricao: String
  valor: BigDecimal
  tipo: String        ("RECEITA" ou "DESPESA")
  categoria: String   (ex: "Alimentação", "Transporte", "Salário")
  data: String no formato "YYYY-MM-DD"
}
```

## Como rodar

```bash
mvn spring-boot:run
```

A API sobe em `http://localhost:8080`. Os dados ficam só na memória: se você parar a aplicação, tudo é perdido (é esperado, pois é assim que o exercício pede).

## Endpoints

Base URL: `http://localhost:8080/api/transacoes`

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/transacoes` | Lista todas (ou filtradas) |
| GET | `/api/transacoes/{id}` | Busca uma transação pelo id |
| POST | `/api/transacoes` | Cadastra uma nova transação |
| PUT | `/api/transacoes/{id}` | Atualiza uma transação existente |
| DELETE | `/api/transacoes/{id}` | Exclui uma transação |

### Filtros combináveis (`@RequestParam`, todos opcionais)

| Parâmetro | Tipo | Exemplo |
|---|---|---|
| `tipo` | String | `?tipo=DESPESA` |
| `categoria` | String | `?categoria=Alimentação` |
| `descricao` | String | `?descricao=mercado` (busca parcial) |
| `valorMin` | BigDecimal | `?valorMin=50` |
| `valorMax` | BigDecimal | `?valorMax=500` |

Exemplo combinando três filtros:
```
GET /api/transacoes?tipo=DESPESA&categoria=Alimentação&valorMax=200
```

## Exemplo de JSON para POST/PUT

```json
{
  "descricao": "Compra no mercado",
  "valor": 185.50,
  "tipo": "DESPESA",
  "categoria": "Alimentação",
  "data": "2026-09-20"
}
```
